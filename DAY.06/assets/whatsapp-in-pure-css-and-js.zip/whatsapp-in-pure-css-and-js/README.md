# WhatsApp in Pure CSS and JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/zenorocha/pen/eZxYOK](https://codepen.io/zenorocha/pen/eZxYOK).

